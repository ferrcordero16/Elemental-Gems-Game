from flask import Flask, render_template, redirect

app = Flask(__name__, static_folder="static")  # Asegura que Flask reconoce el folder static

# Home Page
@app.route("/")
def home():
    return render_template("index.html")

# About Page
@app.route("/about")
def about():
    return render_template("about.html")

# Redirect to Genially Game
@app.route("/play")
def play():
    return redirect("https://view.genially.com/6746531f4bc03be55834ebdc/interactive-content-breakout-service-engineer")

# Example of Other Routes (Earth and Victory pages)
@app.route("/earth")
def earth():
    return render_template("earth.html")

@app.route("/victory")
def victory():
    return render_template("victory.html")

# ✅ FIXED: Author Page Route (Moved Above if __name__ == "__main__")
@app.route("/author")
def author():
    return render_template("author.html")

if __name__ == "__main__":
    app.run(debug=True)
